﻿using FitBuddy.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace FitBuddy.DAL
{
    public class UserProgressContext : DbContext
    {
        public UserProgressContext() : base("Data Source=DESKTOP-9TVPAS9\\SQLEXPRESS01;Initial Catalog=FitBuddy;Integrated Security=True;MultipleActiveResultSets=True;Application Name=EntityFramework")
        {

        }

        public DbSet<UserProgress> Progress { get; set; }
    }
}